<?php
	$fp=fopen("../datas/".str_replace(":","",$_POST['id']).".json","w+");
	fwrite($fp,"{\"Temperature\":\"".$_POST['temp']."\",\"Humidity\":\"".$_POST['hum']."\",\"Pression\":\"".$_POST['pression']."\",\"Tension\":\"".$_POST['v']."\"}");
	fclose($fp);
	
?>	
