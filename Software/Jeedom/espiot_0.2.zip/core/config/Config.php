<?php

global $deviceConfiguration;
$deviceConfiguration = array(
    'Config' => array(
				'name' => 'Config',
				'isVisible' => 1,
				'isEnable' => 1,
				'category' => array('automatism' => '1'),
				'configuration' => array('autorefresh' => '*/15 * * * *'),
				'commands' => array(
							array('name' => 'Temperature', 'type' => 'info', 'subtype' => 'numeric', 'isVisible' => 1, 'isHistorized' => 1, 'unite' => '�c', 'eventOnly' => 0,'value' => ''),						
							array('name' => 'Humidity', 'type' => 'info', 'subtype' => 'numeric', 'isVisible' => 1, 'isHistorized' => 1, 'unite' => '%','minValue'=>0, 'maxValue'=>100, 'eventOnly' => 0,'value' => ''),
							array('name' => 'Tension', 'type' => 'info', 'subtype' => 'numeric', 'isVisible' => 1, 'isHistorized' => 1, 'unite' => 'v', 'eventOnly' => 0,'value' => '')
						)
					)
				);
?>
